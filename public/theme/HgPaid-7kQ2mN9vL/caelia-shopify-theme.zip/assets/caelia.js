(() => {
  const cfg = window.CAELIA || { drawer: true, routes: {} };
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const FOCUSABLE =
    'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

  const visibleFocusable = (root) =>
    [...root.querySelectorAll(FOCUSABLE)].filter((el) => {
      if (el.hasAttribute("hidden") || el.getAttribute("aria-hidden") === "true") return false;
      const s = getComputedStyle(el);
      return s.display !== "none" && s.visibility !== "hidden";
    });

  const announce = (msg) => {
    const el = document.querySelector("[data-cart-status]");
    if (!el) return;
    el.textContent = "";
    requestAnimationFrame(() => {
      el.textContent = msg;
    });
  };

  let trapRoot = null;
  let lastFocus = null;

  const onTrapTab = (e) => {
    if (e.key !== "Tab" || !trapRoot) return;
    const nodes = visibleFocusable(trapRoot);
    if (!nodes.length) return;
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  };

  const lockPage = (lock) => {
    document.body.style.overflow = lock ? "hidden" : "";
    const main = document.getElementById("MainContent");
    const footer = document.querySelector(".c-footer");
    const announceBar = document.querySelector(".c-announce");
    [main, footer, announceBar].forEach((n) => {
      if (!n) return;
      if (lock) n.setAttribute("inert", "");
      else n.removeAttribute("inert");
    });
  };

  const startTrap = (root) => {
    trapRoot = root;
    document.addEventListener("keydown", onTrapTab);
    const nodes = visibleFocusable(root);
    (nodes[0] || root).focus();
  };

  const endTrap = () => {
    document.removeEventListener("keydown", onTrapTab);
    trapRoot = null;
    lockPage(false);
    if (lastFocus && typeof lastFocus.focus === "function") lastFocus.focus();
    lastFocus = null;
  };

  const menu = document.querySelector("[data-menu]");
  const toggle = document.querySelector("[data-menu-toggle]");

  const setMenu = (open) => {
    if (!menu || !toggle) return;
    if (open) {
      lastFocus = document.activeElement;
      menu.removeAttribute("hidden");
      menu.removeAttribute("inert");
      menu.setAttribute("aria-hidden", "false");
      toggle.setAttribute("aria-expanded", "true");
      lockPage(true);
      startTrap(menu);
    } else {
      menu.setAttribute("hidden", "");
      menu.setAttribute("inert", "");
      menu.setAttribute("aria-hidden", "true");
      toggle.setAttribute("aria-expanded", "false");
      endTrap();
    }
  };

  if (toggle && menu) {
    menu.setAttribute("inert", "");
    toggle.addEventListener("click", () => setMenu(menu.hasAttribute("hidden")));
    menu.querySelector("[data-menu-close]")?.addEventListener("click", () => setMenu(false));
  }

  const drawerEl = () => document.querySelector("[data-cart-drawer]");
  const cartToggle = () => document.querySelector("[data-cart-toggle]");

  const setOpen = (open) => {
    const drawer = drawerEl();
    if (!drawer) return;
    const panel = drawer.querySelector(".c-drawer__panel") || drawer;
    drawer.classList.toggle("is-open", open);
    drawer.setAttribute("aria-hidden", open ? "false" : "true");
    if (open) drawer.removeAttribute("inert");
    else drawer.setAttribute("inert", "");
    cartToggle()?.setAttribute("aria-expanded", String(open));
    if (open) {
      lastFocus = document.activeElement;
      lockPage(true);
      startTrap(panel);
    } else {
      endTrap();
    }
  };

  const refreshDrawer = async () => {
    const root = cfg.routes.root || "/";
    const res = await fetch(`${root}?section_id=cart-drawer`);
    const html = await res.text();
    const doc = new DOMParser().parseFromString(html, "text/html");
    const next = doc.querySelector("[data-cart-drawer]");
    const cur = drawerEl();
    if (next && cur) cur.replaceWith(next);
    const cart = await fetch(cfg.routes.cart || "/cart.js")
      .then((r) => r.json())
      .catch(() => null);
    document.querySelectorAll("[data-cart-count]").forEach((el) => {
      const n = cart && cart.item_count ? cart.item_count : 0;
      el.textContent = n ? ` (${n})` : "";
    });
    const label = document.querySelector("[data-cart-toggle]");
    if (label && cart) {
      label.setAttribute(
        "aria-label",
        `${label.dataset.cartLabel || "Carrello"}${cart.item_count ? `, ${cart.item_count}` : ""}`,
      );
    }
  };

  document.addEventListener("click", (e) => {
    const openBtn = e.target.closest("[data-cart-toggle]");
    if (openBtn && cfg.drawer) {
      e.preventDefault();
      setOpen(true);
    }
    if (e.target.closest("[data-cart-close]")) setOpen(false);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (drawerEl()?.classList.contains("is-open")) setOpen(false);
    else if (menu && !menu.hasAttribute("hidden")) setMenu(false);
  });

  document.addEventListener("submit", async (e) => {
    const form = e.target.closest("[data-product-form]");
    if (!form || !cfg.drawer) return;
    e.preventDefault();
    const btn = form.querySelector("[data-cta-btn]");
    if (btn) btn.disabled = true;
    try {
      await fetch(cfg.routes.cartAdd || "/cart/add.js", {
        method: "POST",
        headers: { Accept: "application/json" },
        body: new FormData(form),
      });
      await refreshDrawer();
      announce(cfg.added || "Aggiunto al carrello");
      setOpen(true);
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  if (reduce) {
    document.documentElement.classList.add("reduce-motion");
    document.querySelectorAll("video").forEach((v) => {
      v.pause();
      v.removeAttribute("autoplay");
      v.setAttribute("aria-hidden", "true");
    });
  } else {
    document.querySelectorAll("[data-parallax] img").forEach((img) => {
      const frame = img.parentElement;
      const onScroll = () => {
        const r = frame.getBoundingClientRect();
        const vh = window.innerHeight || 1;
        const p = (r.top + r.height / 2 - vh / 2) / vh;
        img.style.transform = `translate3d(0, ${p * -12}%, 0) scale(1.08)`;
      };
      onScroll();
      window.addEventListener("scroll", onScroll, { passive: true });
    });

    const hero = document.querySelector("[data-hero]");
    if (hero) {
      const media = hero.querySelector(".c-hero__media");
      const veil = hero.querySelector(".c-hero__veil");
      const lock = hero.querySelector(".c-hero__lockup");
      const onScroll = () => {
        const r = hero.getBoundingClientRect();
        const total = hero.offsetHeight - window.innerHeight;
        const p = Math.min(1, Math.max(0, -r.top / (total || 1)));
        if (media) {
          media.style.filter = `blur(${(1 - p) * 22}px)`;
          media.style.transform = `scale(${1.18 + p * 0.16})`;
        }
        if (veil) veil.style.opacity = String(0.5 - p * 0.35);
        if (lock) {
          lock.style.opacity = String(Math.min(1, Math.max(0, (p - 0.12) / 0.25)));
          lock.style.filter = `blur(${Math.max(0, 10 - p * 28)}px)`;
        }
      };
      onScroll();
      window.addEventListener("scroll", onScroll, { passive: true });
    }

    const drip = document.querySelector("[data-drip]");
    if (drip) {
      const frames = [...drip.querySelectorAll("[data-drip-frame]")];
      const stage = drip.querySelector("[data-drip-stage]");
      const cap = drip.querySelector("[data-drip-cap]");
      const onDrip = () => {
        const r = drip.getBoundingClientRect();
        const total = drip.offsetHeight - window.innerHeight;
        const p = Math.min(1, Math.max(0, -r.top / (total || 1)));
        const x = p * Math.max(1, frames.length - 1);
        const a = Math.min(frames.length - 1, Math.floor(x));
        const b = Math.min(frames.length - 1, a + 1);
        const t = x - a;
        frames.forEach((img, i) => {
          img.style.opacity = i === a ? "1" : i === b ? String(t) : "0";
        });
        if (stage) {
          stage.style.transform = `scale(${1.04 + p * 0.14})`;
          stage.style.filter = `blur(${Math.max(0, 10 - p * 55)}px)`;
        }
        if (cap) {
          const op = p < 0.1 ? p / 0.1 : p > 0.88 ? Math.max(0.45, 1 - (p - 0.88) / 0.12) : 1;
          cap.style.opacity = String(op);
          cap.style.transform = `translate3d(0, ${p < 0.16 ? (1 - p / 0.16) * 28 : p > 0.88 ? (p - 0.88) * -120 : 0}px, 0)`;
        }
      };
      frames.forEach((img, i) => {
        img.style.opacity = i === 0 ? "1" : "0";
      });
      onDrip();
      window.addEventListener("scroll", onDrip, { passive: true });
    }
  }

  const map = document.querySelector("[data-map]");
  if (map) {
    const card = map.querySelector("[data-map-card]");
    const pins = [...map.querySelectorAll("[data-pin]")];
    const show = (pin) => {
      if (!card || !pin) return;
      card.hidden = false;
      card.querySelector("[data-map-n]").textContent = pin.textContent.trim();
      card.querySelector("[data-map-t]").textContent = pin.dataset.title || "";
      card.querySelector("[data-map-b]").textContent = pin.dataset.body || "";
      pins.forEach((p) => {
        const on = p === pin;
        p.classList.toggle("is-on", on);
        p.setAttribute("aria-pressed", String(on));
      });
      map.querySelectorAll("[data-map-item]").forEach((el) => {
        const on = el.dataset.id === pin.dataset.id;
        el.classList.toggle("is-on", on);
        el.setAttribute("aria-pressed", String(on));
      });
    };
    pins.forEach((pin) => {
      pin.setAttribute("aria-pressed", pin.classList.contains("is-on") ? "true" : "false");
      pin.addEventListener("pointerenter", () => show(pin));
      pin.addEventListener("focus", () => show(pin));
      pin.addEventListener("click", () => show(pin));
    });
    map.querySelectorAll("[data-map-item]").forEach((item) => {
      item.setAttribute("aria-pressed", item.classList.contains("is-on") ? "true" : "false");
      item.addEventListener("click", () => {
        const pin = pins.find((p) => p.dataset.id === item.dataset.id);
        if (pin) show(pin);
      });
    });
    if (pins[0]) show(pins[0]);
  }

  const thumbs = document.querySelectorAll("[data-thumb]");
  const main = document.getElementById("ProductImage");
  thumbs.forEach((btn) => {
    btn.setAttribute("aria-pressed", btn.classList.contains("is-on") ? "true" : "false");
    btn.addEventListener("click", () => {
      thumbs.forEach((b) => {
        const on = b === btn;
        b.classList.toggle("is-on", on);
        b.setAttribute("aria-pressed", String(on));
      });
      if (main) {
        main.src = btn.dataset.thumb;
        const label = btn.getAttribute("aria-label");
        if (label) main.alt = label;
      }
    });
  });

  document.querySelectorAll("[data-zoom]").forEach((stage) => {
    const img = stage.querySelector("img");
    if (!img) return;
    img.style.willChange = "transform";
    let pid = null;
    let raf = 0;
    let latest = null;
    const origin = (e) => {
      const r = stage.getBoundingClientRect();
      const x = Math.min(100, Math.max(0, ((e.clientX - r.left) / r.width) * 100));
      const y = Math.min(100, Math.max(0, ((e.clientY - r.top) / r.height) * 100));
      img.style.transformOrigin = `${x}% ${y}%`;
      img.style.transform = "scale(2.35)";
      img.style.transition = "none";
    };
    const tick = () => {
      raf = 0;
      if (latest) origin(latest);
    };
    const on = (e) => {
      e.preventDefault();
      pid = e.pointerId;
      try { stage.setPointerCapture(e.pointerId); } catch (err) {}
      latest = e;
      origin(e);
    };
    const move = (e) => {
      if (e.pointerType === "mouse") {
        latest = e;
        if (!raf) raf = requestAnimationFrame(tick);
        return;
      }
      if (pid !== e.pointerId) return;
      e.preventDefault();
      latest = e;
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const off = (e) => {
      if (e && e.pointerType === "mouse" && e.type !== "pointerleave") return;
      pid = null;
      img.style.transition = "transform 380ms cubic-bezier(0.23,1,0.32,1)";
      img.style.transform = "scale(1)";
    };
    const opts = { passive: false };
    stage.addEventListener("pointerdown", on, opts);
    stage.addEventListener("pointermove", move, opts);
    stage.addEventListener("pointerup", off);
    stage.addEventListener("pointercancel", off);
    stage.addEventListener("pointerleave", (e) => {
      if (e.pointerType === "mouse") off(e);
    });
    stage.addEventListener("contextmenu", (e) => e.preventDefault());
  });

  document.querySelectorAll("[data-product]").forEach((product) => {
    const script = product.querySelector("[data-variants]");
    const idInput = product.querySelector("[data-variant-id]");
    const fields = [...product.querySelectorAll("[data-option]")];
    if (script && idInput && fields.length) {
      const variants = JSON.parse(script.textContent);
      const names = [...new Set(fields.map((f) => f.name))];
      const sync = () => {
        const key = names
          .map((n) => {
            const checked = product.querySelector(`[name="${n}"]:checked`);
            const el = checked || product.querySelector(`[name="${n}"]`);
            return el ? el.value : "";
          })
          .join(" / ");
        const v = variants.find((x) => x.title === key || (x.options || []).join(" / ") === key);
        if (!v) return;
        idInput.value = v.id;
        const img = document.getElementById("ProductImage");
        if (img && v.featured_image) img.src = v.featured_image.src;
        const btn = product.querySelector("[data-cta-btn]");
        if (btn) {
          btn.disabled = !v.available;
          btn.setAttribute("aria-disabled", String(!v.available));
        }
        product.querySelectorAll("[data-option-label]").forEach((lab, i) => {
          const part = key.split(" / ")[i];
          if (part) lab.textContent = part;
        });
        product.querySelectorAll(".c-swatch__chip").forEach((chip) => {
          const input = chip.querySelector("input");
          chip.classList.toggle("is-on", !!(input && input.checked));
        });
      };
      fields.forEach((s) => s.addEventListener("change", sync));
    }
  });

  const predForm = document.querySelector("[data-pred-form]");
  const predInput = document.querySelector("[data-pred-input]");
  const predBox = document.querySelector("[data-predictive-search]");
  if (predForm && predInput && predBox && cfg.routes.predictive) {
    const list = predBox.querySelector("[data-pred-list]");
    const empty = predBox.querySelector("[data-pred-empty]");
    const all = predBox.querySelector("[data-pred-all]");
    let timer = 0;
    const render = (items, q) => {
      list.innerHTML = "";
      if (!items.length) {
        empty.hidden = false;
        predBox.hidden = false;
        return;
      }
      empty.hidden = true;
      items.forEach((p) => {
        const li = document.createElement("li");
        const a = document.createElement("a");
        a.href = p.url;
        a.textContent = p.title;
        li.appendChild(a);
        list.appendChild(li);
      });
      if (all) all.href = `${cfg.routes.search}?q=${encodeURIComponent(q)}`;
      predBox.hidden = false;
    };
    predInput.addEventListener("input", () => {
      const q = predInput.value.trim();
      clearTimeout(timer);
      if (q.length < 2) {
        predBox.hidden = true;
        return;
      }
      timer = setTimeout(async () => {
        try {
          const url = `${cfg.routes.predictive}?q=${encodeURIComponent(q)}&resources[type]=product&resources[limit]=4&resources[options][unavailable_products]=last`;
          const res = await fetch(url);
          const json = await res.json();
          const items = (json.resources && json.resources.results && json.resources.results.products) || [];
          render(items, q);
        } catch (e) {
          predBox.hidden = true;
        }
      }, 180);
    });
    document.addEventListener("click", (e) => {
      if (!predBox.contains(e.target) && e.target !== predInput) predBox.hidden = true;
    });
  }

  document.querySelectorAll("[data-recs]").forEach((el) => {
    const url = el.getAttribute("data-url");
    if (!url || !url.includes("product_id=")) return;
    fetch(url)
      .then((r) => r.text())
      .then((html) => {
        const doc = new DOMParser().parseFromString(html, "text/html");
        const next = doc.querySelector("[data-recs]");
        if (next && next.querySelector(".c-card")) el.replaceWith(next);
        else if (!el.querySelector(".c-card")) el.style.display = "none";
      })
      .catch(() => {
        if (!el.querySelector(".c-card")) el.style.display = "none";
      });
  });

  const ctaBtn = document.querySelector("[data-cta-btn]");
  if (ctaBtn && !ctaBtn.disabled) {
    const variant = document.documentElement.getAttribute("data-cta") || "A";
    const track = (action) => {
      const payload = { event: `cta_ab_${action}`, variant, experiment: "buy_button" };
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push(payload);
      if (window.Shopify && Shopify.analytics && typeof Shopify.analytics.publish === "function") {
        Shopify.analytics.publish(payload.event, { variant, experiment: "buy_button" });
      }
    };
    track("view");
    ctaBtn.addEventListener("click", () => track("click"));
  }

  document.querySelectorAll("[data-card-swatch]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const src = btn.getAttribute("data-card-swatch");
      const img = btn.closest(".c-card")?.querySelector(".c-card__img, .c-card__frame img");
      if (src && img) img.src = src;
    });
  });

  const sticky = document.querySelector("[data-sticky-atc]");
  const formEl = document.querySelector("[data-product-form]");
  if (sticky && formEl && "IntersectionObserver" in window) {
    const io = new IntersectionObserver((entries) => {
      sticky.hidden = entries[0].isIntersecting;
    });
    io.observe(formEl);
    sticky.querySelector("[data-sticky-submit]")?.addEventListener("click", () => {
      formEl.requestSubmit();
    });
  }

  const qv = document.querySelector("[data-quick-dialog]");
  const qvBody = document.querySelector("[data-qv-body]");
  document.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-quick-view]");
    if (!btn || !qv || !qvBody) return;
    e.preventDefault();
    try {
      const res = await fetch(btn.getAttribute("data-quick-view"));
      const p = await res.json();
      const img = (p.featured_image || (p.images && p.images[0]) || "").replace(".jpg", "_800x.jpg");
      qvBody.innerHTML = `<img alt="${p.title}" src="${img}"><h2 class="type-display-md">${p.title}</h2><p>${(p.price / 100).toFixed(2)} €</p><a class="btn-primary" href="${p.url}">${p.title}</a>`;
      if (typeof qv.showModal === "function") qv.showModal();
    } catch (err) {
      window.location.href = btn.getAttribute("data-quick-view").replace(/\.js$/, "");
    }
  });
  document.querySelector("[data-qv-close]")?.addEventListener("click", () => qv?.close());

  document.querySelectorAll("[data-slideshow]").forEach((root) => {
    const items = [...root.querySelectorAll(".c-slide__item")];
    if (items.length < 2) return;
    let i = 0;
    const go = (n) => {
      items[i].classList.remove("is-on");
      i = (n + items.length) % items.length;
      items[i].classList.add("is-on");
    };
    root.querySelector("[data-slide-next]")?.addEventListener("click", () => go(i + 1));
    root.querySelector("[data-slide-prev]")?.addEventListener("click", () => go(i - 1));
  });

  document.querySelectorAll("[data-countdown]").forEach((el) => {
    const end = new Date(el.getAttribute("data-countdown")).getTime();
    const tick = () => {
      const d = Math.max(0, end - Date.now());
      const days = Math.floor(d / 86400000);
      const hours = Math.floor((d % 86400000) / 3600000);
      const mins = Math.floor((d % 3600000) / 60000);
      const set = (sel, v) => {
        const n = el.querySelector(sel);
        if (n) n.textContent = String(v);
      };
      set("[data-d]", days);
      set("[data-h]", hours);
      set("[data-m]", mins);
    };
    tick();
    setInterval(tick, 30000);
  });

  const cookie = document.querySelector("[data-cookie]");
  if (cookie) {
    const key = "caelia-consent";
    const saved = localStorage.getItem(key);
    const loadTrack = () => {
      const t = window.CAELIA_TRACK || {};
      if (t.ga && !document.getElementById("caelia-ga")) {
        const s = document.createElement("script");
        s.id = "caelia-ga";
        s.async = true;
        s.src = "https://www.googletagmanager.com/gtag/js?id=" + t.ga;
        document.head.appendChild(s);
        window.dataLayer = window.dataLayer || [];
        function gtag() {
          window.dataLayer.push(arguments);
        }
        window.gtag = gtag;
        gtag("js", new Date());
        gtag("config", t.ga, { anonymize_ip: true });
      }
      if (t.meta && !document.getElementById("caelia-meta")) {
        const s = document.createElement("script");
        s.id = "caelia-meta";
        s.innerHTML =
          "!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','" +
          t.meta +
          "');fbq('track','PageView');";
        document.head.appendChild(s);
      }
    };
    if (!saved) cookie.removeAttribute("hidden");
    if (saved === "accepted") loadTrack();
    cookie.querySelector("[data-cookie-accept]")?.addEventListener("click", () => {
      localStorage.setItem(key, "accepted");
      cookie.setAttribute("hidden", "");
      loadTrack();
    });
    cookie.querySelector("[data-cookie-reject]")?.addEventListener("click", () => {
      localStorage.setItem(key, "rejected");
      cookie.setAttribute("hidden", "");
    });
  }
})();
